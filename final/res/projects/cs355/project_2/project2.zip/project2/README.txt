To run the program open prolog in the directory of the file or 
change directories in prolog or use a path. 

The user can look at the possible disease and a list of all 
available symptoms before adding a new symptom to a patient. 
However if a user try to run test before adding a symptom it will 
crash the program. 

Here are the following menu options:
1- displays all the possible diseases given user provided symptoms 
2- is a list of symptoms to select from within the program
3- adds a symptom (example vomiting . ) note the period follows the word.
4- runs a user selected test.
5- predicts which disease the patient has given the symptoms and a test
6- resets everything back default(no symptoms, no tests). 
7- exits program.  

