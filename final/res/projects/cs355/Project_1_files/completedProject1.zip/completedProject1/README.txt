To run open sml and type use "smallpox.sml";
All the apporiate files are provided in this zip. If you wish to increase the population, which currently is 500 people,  and you are running Linux, use the exectuable provided otherwise compile the population_generator.cpp and tell the population generator how many people you wish to create. 

Thanks 
-Raphael J. Sandor 


